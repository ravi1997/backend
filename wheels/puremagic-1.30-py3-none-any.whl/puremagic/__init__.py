#!/usr/bin/env python
from puremagic.main import *
from puremagic.main import __author__, __version__
